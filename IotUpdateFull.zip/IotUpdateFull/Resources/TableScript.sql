﻿CREATE TABLE [dbo].[iotextendtbl](
 	eventprocessedutctime [datetime2] NULL,
 	id varchar(256) NULL,
 	cycle int NULL,
 	s9 float NULL,
 	s11 float NULL,
 	s14 float NULL,
 	s15 float NULL,
 )
 
 
 CREATE CLUSTERED INDEX [IX_iotextendtbl_Column]
     ON [dbo].[iotextendtbl]([id] ASC, [cycle] ASC, [eventprocessedutctime] ASC);
